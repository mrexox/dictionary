#include <stdio.h>
#include <stdlib.h> // malloc, calloc, free
#include <string.h> // strlen, strcpy, strcmp
#include <math.h>   // pow, sqrt
#include <ctype.h>  // isalnum, isblank
#include "errors.h"
